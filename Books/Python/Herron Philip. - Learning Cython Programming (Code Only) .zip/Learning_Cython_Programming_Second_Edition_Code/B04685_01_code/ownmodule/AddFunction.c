#include <stdio.h>

int AddFunction(int x, int y) {
    printf("look we are within your c code!!\n");
    return x + y;
}
