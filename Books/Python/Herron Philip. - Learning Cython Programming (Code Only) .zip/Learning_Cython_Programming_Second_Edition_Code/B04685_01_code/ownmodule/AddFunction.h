#ifndef __ADDFUNCTION_H__
#define __ADDFUNCTION_H__

extern int AddFunction(int, int);

#endif //__ADDFUNCTION_H__
