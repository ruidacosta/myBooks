#ifndef __DATA_H_
#define __DATA_H_

typedef struct data {
  int value;
} data_t;

#endif //__DATA_H_
