#!/usr/bin/python
import cycode

cycode.func (1)
object = cycode.foobar ()
object.print_me ()
