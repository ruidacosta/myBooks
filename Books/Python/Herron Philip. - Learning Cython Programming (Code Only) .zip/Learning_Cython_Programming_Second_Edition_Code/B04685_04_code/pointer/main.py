#!/usr/bin/env python
from cycode import myfunc
myfunc ()
