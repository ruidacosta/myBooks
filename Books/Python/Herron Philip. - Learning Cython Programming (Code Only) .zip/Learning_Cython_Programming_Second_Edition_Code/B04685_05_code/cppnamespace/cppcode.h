#ifndef __CPPCODE_H__
#define __CPPCODE_H__

namespace mynamespace {
  void myFunc (void);

  class myClass {
  public:
    int x;
    void printMe (void);
  };
};

#endif //__CPPCODE_H__
