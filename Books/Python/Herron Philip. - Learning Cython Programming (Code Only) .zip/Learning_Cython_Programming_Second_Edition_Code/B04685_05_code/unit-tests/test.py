#!/usr/bin/env python
print "Cython C++ Unit test executor"

print "[TEST] std::map"
import testmap
print "[PASS]"

print "[TEST] std::vec"
import testvec
print "[PASS]"

print "Done..."
